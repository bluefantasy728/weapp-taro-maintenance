export default {
  baseUrl: 'http://uat.zeropartner.com/star_service'
};
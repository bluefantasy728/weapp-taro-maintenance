import Nerv from "nervjs";
import Taro, { Component } from "@tarojs/taro-h5";
import { AtInput, AtImagePicker } from 'taro-ui';
import { View } from '@tarojs/components';
import './book_detail.scss';

class BookDetail extends Component {
  static defaultProps = {};
  config = {
    navigationBarTitleText: ''
  };

  state = {
    repairName: '',
    form: {
      remak: '',
      files: [{
        url: 'http://b.hiphotos.baidu.com/image/h%3D300/sign=77d1cd475d43fbf2da2ca023807fca1e/9825bc315c6034a8ef5250cec5134954082376c9.jpg'
      }, {
        url: 'http://b.hiphotos.baidu.com/image/h%3D300/sign=92afee66fd36afc3110c39658318eb85/908fa0ec08fa513db777cf78376d55fbb3fbd9b3.jpg'
      }, {
        url: 'http://a.hiphotos.baidu.com/image/h%3D300/sign=a62e824376d98d1069d40a31113eb807/838ba61ea8d3fd1fc9c7b6853a4e251f94ca5f46.jpg'
      }]
    }
  };

  getRepairName() {
    const levelOneName = Taro.getStorageSync('levelOneItem').repairName;
    const levelTwoName = Taro.getStorageSync('levelTwoItem').repairName;
    this.setState({
      repairName: levelOneName + ' | ' + levelTwoName
    });
  }

  onChangeImg(files) {
    console.log(arguments);
    this.setState({
      form: {
        files
      }
    });
  }
  onImageClick(index, file) {
    console.log(index, file);
  }

  handleChange(value) {
    this.setState({
      value
    });
    // 在小程序中，如果想改变 value 的值，需要 `return value` 从而改变输入框的当前值
    return value;
  }

  componentWillMount() {
    this.getRepairName();
  }

  componentWillReceiveProps(nextProps) {
    console.log(this.state);
    console.log(nextProps);
  }

  componentWillUnmount() {}

  componentDidShow() {}

  componentDidHide() {}

  render() {
    return <View>
        <View className="page-block">
          <AtInput name="value" title="维修项目" disabled type="text" value={this.state.repairName} />
          <AtInput className="test" name="value" title="标准五个字" type="text" placeholder="输入维修说明" value={this.state.form.remak} onChange={this.handleChange.bind(this)} />
          <AtImagePicker multiple={false} files={this.state.form.files} onChange={this.onChangeImg.bind(this)} onImageClick={this.onImageClick.bind(this)} />
        </View>
        <View className="page-block">234</View>
      </View>;
  }

  componentDidMount() {
    super.componentDidMount && super.componentDidMount();
  }

}

export default BookDetail;
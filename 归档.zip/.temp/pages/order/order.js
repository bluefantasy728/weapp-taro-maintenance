import Nerv from "nervjs";
import Taro, { Component } from "@tarojs/taro-h5";
import { View } from '@tarojs/components';

class Order extends Component {
  static defaultProps = {};
  config = {
    navigationBarTitleText: ''
  };

  state = {};

  componentWillMount() {}

  componentWillReceiveProps(nextProps) {}

  componentWillUnmount() {}

  componentDidShow() {}

  componentDidHide() {}

  render() {
    return <View>Order</View>;
  }

  componentDidMount() {
    super.componentDidMount && super.componentDidMount();
  }

}

export default Order;
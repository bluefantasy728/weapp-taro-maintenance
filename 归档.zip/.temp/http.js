import Taro from "@tarojs/taro-h5";
import config from "./config";

export default class Http {
  request(param) {
    const { url, method = 'get' } = param;
    return Taro.request({
      url: config.baseUrl + url,
      method
    });
  }
}
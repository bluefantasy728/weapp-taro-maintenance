import '@tarojs/async-await';
import Taro, { Component } from "@tarojs/taro-h5";
import { Provider } from "@tarojs/redux-h5";

import configStore from "./store/index";

import './app.scss';

import 'taro-ui/dist/style/index.scss'; // 全局引入一次即可

// 如果需要在 h5 环境中开启 React Devtools
// 取消以下注释：
// if (process.env.NODE_ENV !== 'production' && process.env.TARO_ENV === 'h5')  {
//   require('nerv-devtools')
// }

import Nerv from "nervjs";
import { Router, createHistory, mountApis } from '@tarojs/router';
Taro.initPxTransform({
  "designWidth": 750,
  "deviceRatio": {
    "640": 1.17,
    "750": 1,
    "828": 0.905
  }
});

const _taroHistory = createHistory({
  mode: "hash",
  basename: "/",
  customRoutes: {},
  firstPagePath: "/pages/book_detail/book_detail"
});

mountApis(_taroHistory);
const store = configStore();

class App extends Component {
  config = {
    pages: ["/pages/book_detail/book_detail", "/pages/index/index", "/pages/second_repair/second_repair", "/pages/order/order", "/pages/info/info", "/pages/about/about"],
    window: {
      backgroundTextStyle: 'light',
      navigationBarBackgroundColor: '#fff',
      navigationBarTitleText: 'WeChat',
      navigationBarTextStyle: 'black'
    }
    // tabBar: {
    //   color: '#ccc',
    //   selectedColor: '#1660e8',
    //   list: [
    //     {
    //       pagePath: 'pages/index/index',
    //       text: '预约',
    //     },
    //     {
    //       pagePath: 'pages/order/order',
    //       text: '订单',
    //     },
    //     {
    //       pagePath: 'pages/info/info',
    //       text: '我的',
    //     },
    //     {
    //       pagePath: 'pages/about/about',
    //       text: '关于',
    //     },
    //   ],
    // },
  };

  componentDidMount() {
    this.componentDidShow();
  }

  componentDidShow() {}

  componentDidHide() {}

  componentDidCatchError() {}

  // 在 App 类中的 render() 函数没有实际作用
  // 请勿修改此函数
  render() {
    return <Provider store={store}>
                  
              <Router history={_taroHistory} routes={[{
        path: '/pages/book_detail/book_detail',
        componentLoader: () => import( /* webpackChunkName: "book_detail_book_detail" */'./pages/book_detail/book_detail'),
        isIndex: true
      }, {
        path: '/pages/index/index',
        componentLoader: () => import( /* webpackChunkName: "index_index" */'./pages/index/index'),
        isIndex: false
      }, {
        path: '/pages/second_repair/second_repair',
        componentLoader: () => import( /* webpackChunkName: "second_repair_second_repair" */'./pages/second_repair/second_repair'),
        isIndex: false
      }, {
        path: '/pages/order/order',
        componentLoader: () => import( /* webpackChunkName: "order_order" */'./pages/order/order'),
        isIndex: false
      }, {
        path: '/pages/info/info',
        componentLoader: () => import('./pages/info/info'),
        isIndex: false
      }, {
        path: '/pages/about/about',
        componentLoader: () => import( /* webpackChunkName: "about_about" */'./pages/about/about'),
        isIndex: false
      }]} customRoutes={{}} />
              
                </Provider>;
  }

  componentWillUnmount() {
    this.componentDidHide();
  }

  constructor(props, context) {
    super(props, context);
    Taro._$app = this;
  }

}

Nerv.render(<App />, document.getElementById('app'));